from django.shortcuts import render
from django.template import loader
from .models import Member

def members(request):
    mymembers = Member.objects.all()
    template = loader.get_template('index.html')
    context = {
        'mymembers': mymembers,
    }
    return render(request, 'index.html', context)
